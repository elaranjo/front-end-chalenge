import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cart/CartPage.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"]; const useSyncExternalStore = __vite__cjsImport0_react["useSyncExternalStore"];const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport13_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=373f9018";
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=373f9018";
import { useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=373f9018";
import axios from "/node_modules/.vite/deps/axios.js?v=373f9018";
import { shoppingCartQueries } from "/src/app/cart-queries.ts";
import { catalogReady, discoveryQueries, subscribeCatalogReady } from "/src/app/catalog-queries.ts";
import { sessionManager } from "/src/app/session.ts";
import { formatEth, lineTotal } from "/src/shared/money.ts";
import { Footer } from "/src/features/layout/Footer.tsx";
import { AccountHeader } from "/src/features/account/AccountHeader.tsx";
import { LoadingSkeleton } from "/src/features/shared/LoadingSkeleton.tsx";
import "/src/features/account/wallets.css";
import "/src/features/cart/cart.css";
var _jsxFileName = "/Users/ernanelaranjo/Projects/Testes/frontend-challenge/src/features/cart/CartPage.tsx";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=373f9018";
var _s = $RefreshSig$();
const subscribeSession = (listener) => sessionManager.subscribe(listener);
const sessionGeneration = () => sessionManager.sessionGeneration;
export function CartPage() {
	_s();
	const router = useRouter();
	useSyncExternalStore(subscribeSession, sessionGeneration, () => 0);
	const ready = useSyncExternalStore(subscribeCatalogReady, catalogReady, () => false);
	const cart = useQuery({
		...shoppingCartQueries.current(),
		enabled: ready
	});
	const recommendations = useQuery({
		...discoveryQueries.list({}),
		enabled: ready
	});
	const [coupon, setCoupon] = useState("");
	const [busy, setBusy] = useState(false);
	const [message, setMessage] = useState("");
	const [couponError, setCouponError] = useState(false);
	const [changeNotice, setChangeNotice] = useState(null);
	const data = cart.data;
	const previous = useRef(undefined);
	const blocked = !data?.lines.length || !data.quote || cart.isFetching || cart.isError || data.lines.some((line) => line.quantity > line.available);
	useEffect(() => {
		if (!data) return;
		const old = previous.current;
		previous.current = data;
		if (!old) return;
		if (old.id !== data.id) return;
		const changed = data.lines.filter((line) => {
			const before = old.lines.find((item) => item.lineId === line.lineId);
			return before && (before.unitPrice !== line.unitPrice || before.available !== line.available);
		});
		if (changed.length) setChangeNotice({
			owner: data.id,
			text: `Preço ou disponibilidade atualizado: ${changed.map((line) => line.nft.name).join(", ")}. Revise o carrinho antes de continuar.`
		});
	}, [data]);
	async function mutate(action, lineId = "", quantity = 0) {
		if (busy) return;
		setBusy(true);
		setMessage("");
		setCouponError(false);
		try {
			const { cart: client } = await import("/src/app/marketplace-services.ts");
			const current = await client.reconcile();
			if (action === "change") await client.change(lineId, quantity, current.revision);
			else if (action === "remove") await client.remove(lineId, current.revision);
			else if (action === "apply") await client.applyCoupon(coupon, current.revision);
			else await client.removeCoupon(current.revision);
			if (action === "apply" || action === "removeCoupon") setCoupon("");
		} catch (error) {
			const text = axios.isAxiosError(error) ? error.response?.data?.error?.message : undefined;
			setCouponError(action === "apply");
			setMessage(text || "Não foi possível atualizar o carrinho. Tente novamente.");
		} finally {
			setBusy(false);
		}
	}
	async function retryCart() {
		const generation = sessionManager.sessionGeneration;
		const { realtime } = await import("/src/app/realtime.ts");
		if (sessionManager.sessionGeneration !== generation) return;
		realtime.retryReconciliation();
		await cart.refetch();
	}
	function apply(event) {
		event.preventDefault();
		if (coupon.trim()) void mutate("apply");
	}
	function checkout() {
		if (blocked || busy) return;
		void router.navigate({ href: sessionManager.session ? "/checkout" : "/login?returnTo=%2Fcheckout" });
	}
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "cart-page",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "cart-desktop-header",
				children: /* @__PURE__ */ _jsxDEV(AccountHeader, { active: "market" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 42
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "cart-layout",
				children: [/* @__PURE__ */ _jsxDEV("section", {
					className: "cart-content",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "cart-title",
							children: [/* @__PURE__ */ _jsxDEV("a", {
								href: "/",
								"aria-label": "Voltar ao início",
								children: /* @__PURE__ */ _jsxDEV("img", {
									src: "/assets/icons/back-detail-mobile.svg",
									alt: ""
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 76,
									columnNumber: 138
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 76,
								columnNumber: 96
							}, this), /* @__PURE__ */ _jsxDEV("h1", { children: "Carrinho de NFTs" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 76,
								columnNumber: 199
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 68
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "cart-breadcrumb",
							children: "Início / Mercado / Carrinho"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 230
						}, this),
						!data && (!ready || cart.isPending) ? /* @__PURE__ */ _jsxDEV(LoadingSkeleton, { kind: "cart" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 46
						}, this) : !data ? /* @__PURE__ */ _jsxDEV("div", {
							role: "alert",
							children: ["Não foi possível carregar o carrinho. ", /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => void cart.refetch(),
								children: "Tentar novamente"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 144
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 88
						}, this) : data.lines.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
							className: "cart-empty",
							children: ["Seu carrinho está vazio. ", /* @__PURE__ */ _jsxDEV("a", {
								href: "/",
								children: "Continuar explorando"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 313
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 262
						}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "cart-table-head",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "NFTs" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 77,
									columnNumber: 391
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "Preço" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 77,
									columnNumber: 408
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "Edições" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 77,
									columnNumber: 426
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "Total" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 77,
									columnNumber: 446
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 358
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "cart-lines",
							children: data.lines.map((line) => /* @__PURE__ */ _jsxDEV("article", {
								className: "cart-line",
								children: [
									/* @__PURE__ */ _jsxDEV("img", {
										src: line.nft.artUrl,
										alt: ""
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 77,
										columnNumber: 573
									}, this),
									/* @__PURE__ */ _jsxDEV("img", {
										className: "cart-art-overlay",
										src: line.nft.artUrl,
										alt: "",
										"aria-hidden": "true"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 77,
										columnNumber: 609
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "cart-line-info",
										children: [
											/* @__PURE__ */ _jsxDEV("strong", { children: line.nft.name }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 77,
												columnNumber: 725
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "cart-edition",
												children: ["Edição: ", line.nft.editions.find((edition) => edition.id === line.editionId)?.label]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 77,
												columnNumber: 757
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "cart-token",
												children: ["ID do token: ", line.nft.tokenId]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 77,
												columnNumber: 878
											}, this),
											/* @__PURE__ */ _jsxDEV("b", { children: [formatEth(lineTotal(line.unitPrice, line.quantity)), " ETH"] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 77,
												columnNumber: 945
											}, this),
											line.quantity > line.available && /* @__PURE__ */ _jsxDEV("span", {
												role: "alert",
												children: ["Estoque disponível: ", line.available]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 77,
												columnNumber: 1044
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 77,
										columnNumber: 693
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "cart-unit",
										children: [line.unitPrice, " ETH"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 77,
										columnNumber: 1113
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "cart-stepper",
										children: [
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												"aria-label": `Diminuir quantidade de ${line.nft.name}`,
												disabled: busy || !ready || line.quantity <= 1,
												onClick: () => void mutate("change", line.lineId, line.quantity - 1),
												children: "−"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 77,
												columnNumber: 1198
											}, this),
											/* @__PURE__ */ _jsxDEV("span", { children: line.quantity }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 77,
												columnNumber: 1403
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												"aria-label": `Aumentar quantidade de ${line.nft.name}`,
												disabled: busy || !ready || line.quantity >= line.available,
												onClick: () => void mutate("change", line.lineId, line.quantity + 1),
												children: "+"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 77,
												columnNumber: 1431
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 77,
										columnNumber: 1168
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "cart-line-total",
										children: [formatEth(lineTotal(line.unitPrice, line.quantity)), " ETH"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 77,
										columnNumber: 1655
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										className: "cart-remove",
										type: "button",
										disabled: busy || !ready,
										onClick: () => void mutate("remove", line.lineId),
										"aria-label": `Remover ${line.nft.name}`,
										children: /* @__PURE__ */ _jsxDEV("picture", { children: [/* @__PURE__ */ _jsxDEV("source", {
											media: "(min-width: 1280px)",
											srcSet: "/assets/icons/cart-remove-desktop.svg"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 77,
											columnNumber: 1925
										}, this), /* @__PURE__ */ _jsxDEV("img", {
											src: "/assets/icons/cart-remove.svg",
											alt: ""
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 77,
											columnNumber: 2010
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 77,
											columnNumber: 1916
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 77,
										columnNumber: 1753
									}, this)
								]
							}, line.lineId, true, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 524
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 470
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 356
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 34
				}, this), /* @__PURE__ */ _jsxDEV("section", {
					className: "cart-summary",
					"aria-label": "Resumo da carteira",
					children: [
						/* @__PURE__ */ _jsxDEV("h2", { children: "Resumo da carteira" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 81
						}, this),
						data && cart.isError && /* @__PURE__ */ _jsxDEV("p", {
							className: "cart-error",
							role: "alert",
							children: ["Não foi possível atualizar o carrinho. Os valores exibidos podem estar desatualizados. ", /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => void retryCart(),
								children: "Tentar novamente"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 259
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 133
						}, this),
						data && cart.isFetching && /* @__PURE__ */ _jsxDEV("p", {
							role: "status",
							children: "Atualizando o carrinho..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 372
						}, this),
						changeNotice && data?.id === changeNotice.owner && /* @__PURE__ */ _jsxDEV("p", {
							className: "cart-error",
							role: "status",
							children: changeNotice.text
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 471
						}, this),
						/* @__PURE__ */ _jsxDEV("form", {
							onSubmit: apply,
							children: [/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: "coupon",
								className: "cart-coupon-label",
								children: "Código promocional"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 558
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "cart-coupon",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									id: "coupon",
									value: coupon,
									onChange: (event) => {
										setCoupon(event.target.value);
										if (couponError) {
											setCouponError(false);
											setMessage("");
										}
									},
									"aria-invalid": couponError,
									"aria-describedby": couponError ? "cart-error" : undefined,
									placeholder: "Digite o código promocional..."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 78,
									columnNumber: 667
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									disabled: busy || !ready || !coupon.trim(),
									children: "Aplicar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 78,
									columnNumber: 949
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 638
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 535
						}, this),
						data?.couponCode && /* @__PURE__ */ _jsxDEV("p", {
							className: "cart-applied",
							children: [
								data.couponCode,
								" ",
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									disabled: busy || !ready,
									onClick: () => void mutate("removeCoupon"),
									children: "Remover cupom"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 78,
									columnNumber: 1097
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 1051
						}, this),
						message && /* @__PURE__ */ _jsxDEV("p", {
							id: "cart-error",
							className: "cart-error",
							role: "alert",
							children: message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 1228
						}, this),
						data?.adjustments.map((adjustment) => /* @__PURE__ */ _jsxDEV("p", {
							className: "cart-error",
							role: "status",
							children: adjustment === "COUPON_EXPIRED" ? "O cupom expirou." : adjustment
						}, adjustment, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 1336
						}, this)),
						data?.quote ? /* @__PURE__ */ _jsxDEV("dl", {
							className: "cart-totals",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Subtotal" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 55
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: [data.quote.subtotal, " ETH"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 72
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 50
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Desconto do lançamento" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 117
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: ["(−) ", data.quote.discount] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 148
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 112
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Taxa de rede" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 193
								}, this), /* @__PURE__ */ _jsxDEV("dd", { children: [
									data.quote.networkFee,
									" ETH",
									/* @__PURE__ */ _jsxDEV("small", { children: "Taxa estimada" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 79,
										columnNumber: 245
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 214
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 188
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "cart-total",
									children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Total" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 79,
										columnNumber: 312
									}, this), /* @__PURE__ */ _jsxDEV("dd", { children: [data.quote.total, " ETH"] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 79,
										columnNumber: 326
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 284
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 22
						}, this) : data || cart.isError ? /* @__PURE__ */ _jsxDEV("p", {
							role: "alert",
							children: ["Resumo indisponível. ", /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => void retryCart(),
								children: "Tentar novamente"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 79,
								columnNumber: 431
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 394
						}, this) : /* @__PURE__ */ _jsxDEV(LoadingSkeleton, { kind: "summary" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 518
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							className: "cart-checkout",
							type: "button",
							disabled: blocked || busy || !ready,
							onClick: checkout,
							children: "Conectar e finalizar"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 7
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							className: "cart-continue",
							href: "/",
							children: "Continuar explorando"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 140
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "cart-recommendations",
				"aria-labelledby": "cart-recommendations-title",
				children: [
					/* @__PURE__ */ _jsxDEV("h2", {
						id: "cart-recommendations-title",
						children: "Colecionadores também viram"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 108
					}, this),
					recommendations.isPending ? /* @__PURE__ */ _jsxDEV("p", {
						role: "status",
						children: "Carregando NFTs..."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 205
					}, this) : recommendations.isError ? /* @__PURE__ */ _jsxDEV("p", {
						role: "alert",
						children: ["Não foi possível carregar os NFTs. ", /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => void recommendations.refetch(),
							children: "Tentar novamente"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 324
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 273
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "cart-recommendation-grid",
						children: recommendations.data?.items.slice(3, 8).map((nft) => /* @__PURE__ */ _jsxDEV("article", { children: /* @__PURE__ */ _jsxDEV("a", {
							href: `/nfts/${encodeURIComponent(nft.id)}`,
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "cart-recommendation-art",
									children: /* @__PURE__ */ _jsxDEV("img", {
										src: nft.artUrl,
										alt: ""
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 81,
										columnNumber: 633
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 81,
									columnNumber: 591
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: nft.name }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 81,
									columnNumber: 671
								}, this),
								/* @__PURE__ */ _jsxDEV("strong", { children: [nft.editions[0]?.unitPrice, " ETH"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 81,
									columnNumber: 694
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 543
						}, this) }, nft.id, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 521
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 425
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "cart-recommendation-dots",
						"aria-hidden": "true",
						children: [
							/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 81,
								columnNumber: 827
							}, this),
							/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 81,
								columnNumber: 832
							}, this),
							/* @__PURE__ */ _jsxDEV("i", {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 81,
								columnNumber: 837
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 766
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 21
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "cart-footer",
				children: /* @__PURE__ */ _jsxDEV(Footer, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 887
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 858
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 74,
		columnNumber: 10
	}, this);
}
_s(CartPage, "ZLPrVSSgZJohbt4ItAtTRfwBeYU=", false, function() {
	return [
		useRouter,
		useQuery,
		useQuery
	];
});
_c = CartPage;
var _c;
$RefreshReg$(_c, "CartPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/cart/CartPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ernanelaranjo/Projects/Testes/frontend-challenge/src/features/cart/CartPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/ernanelaranjo/Projects/Testes/frontend-challenge/src/features/cart/CartPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/ernanelaranjo/Projects/Testes/frontend-challenge/src/features/cart/CartPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLFFBQVEsVUFBVSw0QkFBNEM7QUFDbEYsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxpQkFBaUI7QUFDMUIsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsMkJBQTJCO0FBQ3BDLFNBQVMsY0FBYyxrQkFBa0IsNkJBQTZCO0FBQ3RFLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsV0FBVyxpQkFBaUI7QUFDckMsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsdUJBQXVCO0FBQ2hDLE9BQU87QUFDUCxPQUFPOzs7O0FBRVAsTUFBTSxvQkFBb0IsYUFBeUIsZUFBZSxVQUFVLFFBQVE7QUFDcEYsTUFBTSwwQkFBMEIsZUFBZTtBQUUvQyxPQUFPLFNBQVMsV0FBVzs7Q0FDekIsTUFBTSxTQUFTLFVBQVU7Q0FDekIscUJBQXFCLGtCQUFrQix5QkFBeUIsQ0FBQztDQUNqRSxNQUFNLFFBQVEscUJBQXFCLHVCQUF1QixvQkFBb0IsS0FBSztDQUNuRixNQUFNLE9BQU8sU0FBUztFQUFFLEdBQUcsb0JBQW9CLFFBQVE7RUFBRyxTQUFTO0NBQU0sQ0FBQztDQUMxRSxNQUFNLGtCQUFrQixTQUFTO0VBQUUsR0FBRyxpQkFBaUIsS0FBSyxDQUFDLENBQUM7RUFBRyxTQUFTO0NBQU0sQ0FBQztDQUNqRixNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsRUFBRTtDQUN2QyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsS0FBSztDQUN0QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUN6QyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBQ3BELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFpRCxJQUFJO0NBQzdGLE1BQU0sT0FBTyxLQUFLO0NBQ2xCLE1BQU0sV0FBVyxPQUFvQixTQUFTO0NBQzlDLE1BQU0sVUFBVSxDQUFDLE1BQU0sTUFBTSxVQUFVLENBQUMsS0FBSyxTQUFTLEtBQUssY0FBYyxLQUFLLFdBQVcsS0FBSyxNQUFNLE1BQU0sU0FBUyxLQUFLLFdBQVcsS0FBSyxTQUFTO0NBQ2pKLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxNQUFNO0VBQ1gsTUFBTSxNQUFNLFNBQVM7RUFDckIsU0FBUyxVQUFVO0VBQ25CLElBQUksQ0FBQyxLQUFLO0VBQ1YsSUFBSSxJQUFJLE9BQU8sS0FBSyxJQUFJO0VBQ3hCLE1BQU0sVUFBVSxLQUFLLE1BQU0sUUFBUSxTQUFTO0dBQzFDLE1BQU0sU0FBUyxJQUFJLE1BQU0sTUFBTSxTQUFTLEtBQUssV0FBVyxLQUFLLE1BQU07R0FDbkUsT0FBTyxXQUFXLE9BQU8sY0FBYyxLQUFLLGFBQWEsT0FBTyxjQUFjLEtBQUs7RUFDckYsQ0FBQztFQUNELElBQUksUUFBUSxRQUFRLGdCQUFnQjtHQUFFLE9BQU8sS0FBSztHQUFJLE1BQU0sd0NBQXdDLFFBQVEsS0FBSyxTQUFTLEtBQUssSUFBSSxJQUFJLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRTtFQUF5QyxDQUFDO0NBQ2hNLEdBQUcsQ0FBQyxJQUFJLENBQUM7Q0FFVCxlQUFlLE9BQU8sUUFBd0QsU0FBUyxJQUFJLFdBQVcsR0FBRztFQUN2RyxJQUFJLE1BQU07RUFDVixRQUFRLElBQUk7RUFBRyxXQUFXLEVBQUU7RUFBRyxlQUFlLEtBQUs7RUFDbkQsSUFBSTtHQUNGLE1BQU0sRUFBRSxNQUFNLFdBQVcsTUFBTSxPQUFPO0dBQ3RDLE1BQU0sVUFBVSxNQUFNLE9BQU8sVUFBVTtHQUN2QyxJQUFJLFdBQVcsVUFBVSxNQUFNLE9BQU8sT0FBTyxRQUFRLFVBQVUsUUFBUSxRQUFRO1FBQzFFLElBQUksV0FBVyxVQUFVLE1BQU0sT0FBTyxPQUFPLFFBQVEsUUFBUSxRQUFRO1FBQ3JFLElBQUksV0FBVyxTQUFTLE1BQU0sT0FBTyxZQUFZLFFBQVEsUUFBUSxRQUFRO1FBQ3pFLE1BQU0sT0FBTyxhQUFhLFFBQVEsUUFBUTtHQUMvQyxJQUFJLFdBQVcsV0FBVyxXQUFXLGdCQUFnQixVQUFVLEVBQUU7RUFDbkUsU0FBUyxPQUFPO0dBQ2QsTUFBTSxPQUFPLE1BQU0sYUFBYSxLQUFLLElBQUksTUFBTSxVQUFVLE1BQU0sT0FBTyxVQUFVO0dBQ2hGLGVBQWUsV0FBVyxPQUFPO0dBQ2pDLFdBQVcsUUFBUSx5REFBeUQ7RUFDOUUsVUFBVTtHQUFFLFFBQVEsS0FBSztFQUFFO0NBQzdCO0NBQ0EsZUFBZSxZQUFZO0VBQ3pCLE1BQU0sYUFBYSxlQUFlO0VBQ2xDLE1BQU0sRUFBRSxhQUFhLE1BQU0sT0FBTztFQUNsQyxJQUFJLGVBQWUsc0JBQXNCLFlBQVk7RUFDckQsU0FBUyxvQkFBb0I7RUFDN0IsTUFBTSxLQUFLLFFBQVE7Q0FDckI7Q0FDQSxTQUFTLE1BQU0sT0FBbUM7RUFBRSxNQUFNLGVBQWU7RUFBRyxJQUFJLE9BQU8sS0FBSyxHQUFHLEtBQUssT0FBTyxPQUFPO0NBQUU7Q0FDcEgsU0FBUyxXQUFXO0VBQ2xCLElBQUksV0FBVyxNQUFNO0VBQ3JCLEtBQUssT0FBTyxTQUFTLEVBQUUsTUFBTSxlQUFlLFVBQVUsY0FBYyw4QkFBOEIsQ0FBQztDQUNyRztDQUNBLE9BQU8sd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFBaEI7R0FDTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFzQix3QkFBQyxlQUFELEVBQWUsUUFBTyxTQUFVOzs7OztHQUFNOzs7OztHQUMzRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQTZCLHdCQUFDLFdBQUQ7S0FBUyxXQUFVO2VBQW5CO01BQWtDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQTRCLHdCQUFDLEtBQUQ7UUFBRyxNQUFLO1FBQUksY0FBVztrQkFBbUIsd0JBQUMsT0FBRDtTQUFLLEtBQUk7U0FBdUMsS0FBSTtRQUFJOzs7OztPQUFJOzs7O2lCQUFDLHdCQUFDLE1BQUQsWUFBSSxtQkFBb0I7Ozs7ZUFBTTs7Ozs7O01BQUMsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWtCO01BQThCOzs7OztNQUMzUixDQUFDLFNBQVMsQ0FBQyxTQUFTLEtBQUssYUFBYSx3QkFBQyxpQkFBRCxFQUFpQixNQUFLLE9BQVE7Ozs7aUJBQUksQ0FBQyxPQUFPLHdCQUFDLE9BQUQ7T0FBSyxNQUFLO2lCQUFWLENBQWtCLDBDQUFzQyx3QkFBQyxVQUFEO1FBQVEsTUFBSztRQUFTLGVBQWUsS0FBSyxLQUFLLFFBQVE7a0JBQUc7T0FBd0I7Ozs7ZUFBTTs7Ozs7aUJBQUksS0FBSyxNQUFNLFdBQVcsSUFBSSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYixDQUEwQiw2QkFBeUIsd0JBQUMsS0FBRDtRQUFHLE1BQUs7a0JBQUk7T0FBdUI7Ozs7ZUFBSTs7Ozs7aUJBQUksZ0RBQUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFBaUMsd0JBQUMsUUFBRCxZQUFNLE9BQVU7Ozs7O1FBQUMsd0JBQUMsUUFBRCxZQUFNLFFBQVc7Ozs7O1FBQUMsd0JBQUMsUUFBRCxZQUFNLFVBQWE7Ozs7O1FBQUMsd0JBQUMsUUFBRCxZQUFNLFFBQVc7Ozs7O09BQU07Ozs7O2dCQUFDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFjLEtBQUssTUFBTSxLQUFLLFNBQVMsd0JBQUMsV0FBRDtRQUFTLFdBQVU7a0JBQW5CO1NBQWlELHdCQUFDLE9BQUQ7VUFBSyxLQUFLLEtBQUssSUFBSTtVQUFRLEtBQUk7U0FBSTs7Ozs7U0FBQyx3QkFBQyxPQUFEO1VBQUssV0FBVTtVQUFtQixLQUFLLEtBQUssSUFBSTtVQUFRLEtBQUk7VUFBRyxlQUFZO1NBQVE7Ozs7O1NBQUMsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FBZ0Msd0JBQUMsVUFBRCxZQUFTLEtBQUssSUFBSSxLQUFhOzs7OztXQUFDLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQixDQUErQixZQUFTLEtBQUssSUFBSSxTQUFTLE1BQU0sWUFBWSxRQUFRLE9BQU8sS0FBSyxTQUFTLENBQUMsRUFBRSxLQUFZOzs7Ozs7V0FBQyx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEIsQ0FBNkIsaUJBQWMsS0FBSyxJQUFJLE9BQWM7Ozs7OztXQUFDLHdCQUFDLEtBQUQsYUFBSSxVQUFVLFVBQVUsS0FBSyxXQUFXLEtBQUssUUFBUSxDQUFDLEdBQUUsTUFBTzs7Ozs7V0FBRSxLQUFLLFdBQVcsS0FBSyxhQUFhLHdCQUFDLFFBQUQ7WUFBTSxNQUFLO3NCQUFYLENBQW1CLHdCQUFxQixLQUFLLFNBQWdCOzs7Ozs7VUFBTzs7Ozs7O1NBQUMsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQTZCLEtBQUssV0FBVSxNQUFVOzs7Ozs7U0FBQyx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUE4Qix3QkFBQyxVQUFEO1lBQVEsTUFBSztZQUFTLGNBQVksMEJBQTBCLEtBQUssSUFBSTtZQUFRLFVBQVUsUUFBUSxDQUFDLFNBQVMsS0FBSyxZQUFZO1lBQUcsZUFBZSxLQUFLLE9BQU8sVUFBVSxLQUFLLFFBQVEsS0FBSyxXQUFXLENBQUM7c0JBQUc7V0FBUzs7Ozs7V0FBQyx3QkFBQyxRQUFELFlBQU8sS0FBSyxTQUFlOzs7OztXQUFDLHdCQUFDLFVBQUQ7WUFBUSxNQUFLO1lBQVMsY0FBWSwwQkFBMEIsS0FBSyxJQUFJO1lBQVEsVUFBVSxRQUFRLENBQUMsU0FBUyxLQUFLLFlBQVksS0FBSztZQUFXLGVBQWUsS0FBSyxPQUFPLFVBQVUsS0FBSyxRQUFRLEtBQUssV0FBVyxDQUFDO3NCQUFHO1dBQVM7Ozs7O1VBQU07Ozs7OztTQUFDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUFtQyxVQUFVLFVBQVUsS0FBSyxXQUFXLEtBQUssUUFBUSxDQUFDLEdBQUUsTUFBVTs7Ozs7O1NBQUMsd0JBQUMsVUFBRDtVQUFRLFdBQVU7VUFBYyxNQUFLO1VBQVMsVUFBVSxRQUFRLENBQUM7VUFBTyxlQUFlLEtBQUssT0FBTyxVQUFVLEtBQUssTUFBTTtVQUFHLGNBQVksV0FBVyxLQUFLLElBQUk7b0JBQVEsd0JBQUMsV0FBRCxhQUFTLHdCQUFDLFVBQUQ7V0FBUSxPQUFNO1dBQXNCLFFBQU87VUFBeUM7Ozs7b0JBQUMsd0JBQUMsT0FBRDtXQUFLLEtBQUk7V0FBZ0MsS0FBSTtVQUFJOzs7O2tCQUFVOzs7OztTQUFTOzs7OztRQUFVO1VBQXgvQyxLQUFLOzs7O2NBQW0vQyxDQUFDO01BQU87Ozs7Y0FBRzs7Ozs7S0FDcmlFOzs7OztjQUFDLHdCQUFDLFdBQUQ7S0FBUyxXQUFVO0tBQWUsY0FBVztlQUE3QztNQUFrRSx3QkFBQyxNQUFELFlBQUkscUJBQXNCOzs7OztNQUFFLFFBQVEsS0FBSyxXQUFXLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO09BQWEsTUFBSztpQkFBL0IsQ0FBdUMsMkZBQXVGLHdCQUFDLFVBQUQ7UUFBUSxNQUFLO1FBQVMsZUFBZSxLQUFLLFVBQVU7a0JBQUc7T0FBd0I7Ozs7ZUFBSTs7Ozs7O01BQUcsUUFBUSxLQUFLLGNBQWMsd0JBQUMsS0FBRDtPQUFHLE1BQUs7aUJBQVM7TUFBNEI7Ozs7O01BQUcsZ0JBQWdCLE1BQU0sT0FBTyxhQUFhLFNBQVMsd0JBQUMsS0FBRDtPQUFHLFdBQVU7T0FBYSxNQUFLO2lCQUFVLGFBQWE7TUFBUTs7Ozs7TUFBRSx3QkFBQyxRQUFEO09BQU0sVUFBVTtpQkFBaEIsQ0FBdUIsd0JBQUMsU0FBRDtRQUFPLFNBQVE7UUFBUyxXQUFVO2tCQUFvQjtPQUF5Qjs7OztpQkFBQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUE2Qix3QkFBQyxTQUFEO1NBQU8sSUFBRztTQUFTLE9BQU87U0FBUSxXQUFXLFVBQVU7VUFBRSxVQUFVLE1BQU0sT0FBTyxLQUFLO1VBQUcsSUFBSSxhQUFhO1dBQUUsZUFBZSxLQUFLO1dBQUcsV0FBVyxFQUFFO1VBQUU7U0FBRTtTQUFHLGdCQUFjO1NBQWEsb0JBQWtCLGNBQWMsZUFBZTtTQUFXLGFBQVk7UUFBa0M7Ozs7a0JBQUMsd0JBQUMsVUFBRDtTQUFRLFVBQVUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEtBQUs7bUJBQUc7UUFBZTs7OztnQkFBTTs7Ozs7ZUFBTzs7Ozs7O01BQUUsTUFBTSxjQUFjLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFiO1FBQTZCLEtBQUs7UUFBVztRQUFDLHdCQUFDLFVBQUQ7U0FBUSxNQUFLO1NBQVMsVUFBVSxRQUFRLENBQUM7U0FBTyxlQUFlLEtBQUssT0FBTyxjQUFjO21CQUFHO1FBQXFCOzs7OztPQUFJOzs7Ozs7TUFBRyxXQUFXLHdCQUFDLEtBQUQ7T0FBRyxJQUFHO09BQWEsV0FBVTtPQUFhLE1BQUs7aUJBQVM7TUFBVzs7Ozs7TUFBRyxNQUFNLFlBQVksS0FBSyxlQUFlLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO09BQWEsTUFBSztpQkFBMkIsZUFBZSxtQkFBbUIscUJBQXFCO01BQWMsR0FBbEY7Ozs7YUFBa0YsQ0FBQztNQUNoN0MsTUFBTSxRQUFRLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQTRCLHdCQUFDLE9BQUQsYUFBSyx3QkFBQyxNQUFELFlBQUksV0FBWTs7OztrQkFBQyx3QkFBQyxNQUFELGFBQUssS0FBSyxNQUFNLFVBQVMsTUFBUTs7OztnQkFBTTs7Ozs7UUFBQyx3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFJLHlCQUEwQjs7OztrQkFBQyx3QkFBQyxNQUFELGFBQUksUUFBSyxLQUFLLE1BQU0sUUFBYTs7OztnQkFBTTs7Ozs7UUFBQyx3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFJLGVBQWdCOzs7O2tCQUFDLHdCQUFDLE1BQUQ7U0FBSyxLQUFLLE1BQU07U0FBVztTQUFJLHdCQUFDLFNBQUQsWUFBTyxnQkFBb0I7Ozs7O1FBQUs7Ozs7Z0JBQU07Ozs7O1FBQUMsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FBNEIsd0JBQUMsTUFBRCxZQUFJLFFBQVM7Ozs7bUJBQUMsd0JBQUMsTUFBRCxhQUFLLEtBQUssTUFBTSxPQUFNLE1BQVE7Ozs7aUJBQU07Ozs7OztPQUFLOzs7OztpQkFBSSxRQUFRLEtBQUssVUFBVSx3QkFBQyxLQUFEO09BQUcsTUFBSztpQkFBUixDQUFnQix5QkFBcUIsd0JBQUMsVUFBRDtRQUFRLE1BQUs7UUFBUyxlQUFlLEtBQUssVUFBVTtrQkFBRztPQUF3Qjs7OztlQUFJOzs7OztpQkFBSSx3QkFBQyxpQkFBRCxFQUFpQixNQUFLLFVBQVc7Ozs7O01BQ2hpQix3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUFnQixNQUFLO09BQVMsVUFBVSxXQUFXLFFBQVEsQ0FBQztPQUFPLFNBQVM7aUJBQVU7TUFBNEI7Ozs7O01BQUMsd0JBQUMsS0FBRDtPQUFHLFdBQVU7T0FBZ0IsTUFBSztpQkFBSTtNQUF1Qjs7Ozs7S0FDM0w7Ozs7O1lBQU07Ozs7OztHQUFDLHdCQUFDLFdBQUQ7SUFBUyxXQUFVO0lBQXVCLG1CQUFnQjtjQUExRDtLQUF1Rix3QkFBQyxNQUFEO01BQUksSUFBRztnQkFBNkI7S0FBK0I7Ozs7O0tBQUUsZ0JBQWdCLFlBQVksd0JBQUMsS0FBRDtNQUFHLE1BQUs7Z0JBQVM7S0FBcUI7Ozs7Z0JBQUksZ0JBQWdCLFVBQVUsd0JBQUMsS0FBRDtNQUFHLE1BQUs7Z0JBQVIsQ0FBZ0IsdUNBQW1DLHdCQUFDLFVBQUQ7T0FBUSxNQUFLO09BQVMsZUFBZSxLQUFLLGdCQUFnQixRQUFRO2lCQUFHO01BQXdCOzs7O2NBQUk7Ozs7O2dCQUFJLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUE0QixnQkFBZ0IsTUFBTSxNQUFNLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsd0JBQUMsV0FBRCxZQUFzQix3QkFBQyxLQUFEO09BQUcsTUFBTSxTQUFTLG1CQUFtQixJQUFJLEVBQUU7aUJBQTNDO1FBQWdELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUEwQix3QkFBQyxPQUFEO1VBQUssS0FBSyxJQUFJO1VBQVEsS0FBSTtTQUFJOzs7OztRQUFPOzs7OztRQUFDLHdCQUFDLFFBQUQsWUFBTyxJQUFJLEtBQVc7Ozs7O1FBQUMsd0JBQUMsVUFBRCxhQUFTLElBQUksU0FBUyxFQUFFLEVBQUUsV0FBVSxNQUFZOzs7OztPQUFJOzs7OztlQUFVLEdBQTdOLElBQUk7Ozs7YUFBeU4sQ0FBQztLQUFPOzs7OztLQUFFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQTJCLGVBQVk7Z0JBQXREO09BQTZELHdCQUFDLEtBQUQsQ0FBSTs7Ozs7T0FBQyx3QkFBQyxLQUFELENBQUk7Ozs7O09BQUMsd0JBQUMsS0FBRCxDQUFJOzs7OztNQUFNOzs7Ozs7SUFBVTs7Ozs7O0dBQUMsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBYyx3QkFBQyxRQUFELENBQVM7Ozs7O0dBQU07Ozs7O0VBQzczQjs7Ozs7O0FBQ1IiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2FydFBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VTdGF0ZSwgdXNlU3luY0V4dGVybmFsU3RvcmUsIHR5cGUgRm9ybUV2ZW50IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnXG5pbXBvcnQgeyBzaG9wcGluZ0NhcnRRdWVyaWVzIH0gZnJvbSAnLi4vLi4vYXBwL2NhcnQtcXVlcmllcy50cydcbmltcG9ydCB7IGNhdGFsb2dSZWFkeSwgZGlzY292ZXJ5UXVlcmllcywgc3Vic2NyaWJlQ2F0YWxvZ1JlYWR5IH0gZnJvbSAnLi4vLi4vYXBwL2NhdGFsb2ctcXVlcmllcy50cydcbmltcG9ydCB7IHNlc3Npb25NYW5hZ2VyIH0gZnJvbSAnLi4vLi4vYXBwL3Nlc3Npb24udHMnXG5pbXBvcnQgeyBmb3JtYXRFdGgsIGxpbmVUb3RhbCB9IGZyb20gJy4uLy4uL3NoYXJlZC9tb25leS50cydcbmltcG9ydCB7IEZvb3RlciB9IGZyb20gJy4uL2xheW91dC9Gb290ZXIudHN4J1xuaW1wb3J0IHsgQWNjb3VudEhlYWRlciB9IGZyb20gJy4uL2FjY291bnQvQWNjb3VudEhlYWRlci50c3gnXG5pbXBvcnQgeyBMb2FkaW5nU2tlbGV0b24gfSBmcm9tICcuLi9zaGFyZWQvTG9hZGluZ1NrZWxldG9uLnRzeCdcbmltcG9ydCAnLi4vYWNjb3VudC93YWxsZXRzLmNzcydcbmltcG9ydCAnLi9jYXJ0LmNzcydcblxuY29uc3Qgc3Vic2NyaWJlU2Vzc2lvbiA9IChsaXN0ZW5lcjogKCkgPT4gdm9pZCkgPT4gc2Vzc2lvbk1hbmFnZXIuc3Vic2NyaWJlKGxpc3RlbmVyKVxuY29uc3Qgc2Vzc2lvbkdlbmVyYXRpb24gPSAoKSA9PiBzZXNzaW9uTWFuYWdlci5zZXNzaW9uR2VuZXJhdGlvblxuXG5leHBvcnQgZnVuY3Rpb24gQ2FydFBhZ2UoKSB7XG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG4gIHVzZVN5bmNFeHRlcm5hbFN0b3JlKHN1YnNjcmliZVNlc3Npb24sIHNlc3Npb25HZW5lcmF0aW9uLCAoKSA9PiAwKVxuICBjb25zdCByZWFkeSA9IHVzZVN5bmNFeHRlcm5hbFN0b3JlKHN1YnNjcmliZUNhdGFsb2dSZWFkeSwgY2F0YWxvZ1JlYWR5LCAoKSA9PiBmYWxzZSlcbiAgY29uc3QgY2FydCA9IHVzZVF1ZXJ5KHsgLi4uc2hvcHBpbmdDYXJ0UXVlcmllcy5jdXJyZW50KCksIGVuYWJsZWQ6IHJlYWR5IH0pXG4gIGNvbnN0IHJlY29tbWVuZGF0aW9ucyA9IHVzZVF1ZXJ5KHsgLi4uZGlzY292ZXJ5UXVlcmllcy5saXN0KHt9KSwgZW5hYmxlZDogcmVhZHkgfSlcbiAgY29uc3QgW2NvdXBvbiwgc2V0Q291cG9uXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbYnVzeSwgc2V0QnVzeV0gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtjb3Vwb25FcnJvciwgc2V0Q291cG9uRXJyb3JdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtjaGFuZ2VOb3RpY2UsIHNldENoYW5nZU5vdGljZV0gPSB1c2VTdGF0ZTx7IG93bmVyOiBzdHJpbmc7IHRleHQ6IHN0cmluZyB9IHwgbnVsbD4obnVsbClcbiAgY29uc3QgZGF0YSA9IGNhcnQuZGF0YVxuICBjb25zdCBwcmV2aW91cyA9IHVzZVJlZjx0eXBlb2YgZGF0YT4odW5kZWZpbmVkKVxuICBjb25zdCBibG9ja2VkID0gIWRhdGE/LmxpbmVzLmxlbmd0aCB8fCAhZGF0YS5xdW90ZSB8fCBjYXJ0LmlzRmV0Y2hpbmcgfHwgY2FydC5pc0Vycm9yIHx8IGRhdGEubGluZXMuc29tZSgobGluZSkgPT4gbGluZS5xdWFudGl0eSA+IGxpbmUuYXZhaWxhYmxlKVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZGF0YSkgcmV0dXJuXG4gICAgY29uc3Qgb2xkID0gcHJldmlvdXMuY3VycmVudFxuICAgIHByZXZpb3VzLmN1cnJlbnQgPSBkYXRhXG4gICAgaWYgKCFvbGQpIHJldHVyblxuICAgIGlmIChvbGQuaWQgIT09IGRhdGEuaWQpIHJldHVyblxuICAgIGNvbnN0IGNoYW5nZWQgPSBkYXRhLmxpbmVzLmZpbHRlcigobGluZSkgPT4ge1xuICAgICAgY29uc3QgYmVmb3JlID0gb2xkLmxpbmVzLmZpbmQoKGl0ZW0pID0+IGl0ZW0ubGluZUlkID09PSBsaW5lLmxpbmVJZClcbiAgICAgIHJldHVybiBiZWZvcmUgJiYgKGJlZm9yZS51bml0UHJpY2UgIT09IGxpbmUudW5pdFByaWNlIHx8IGJlZm9yZS5hdmFpbGFibGUgIT09IGxpbmUuYXZhaWxhYmxlKVxuICAgIH0pXG4gICAgaWYgKGNoYW5nZWQubGVuZ3RoKSBzZXRDaGFuZ2VOb3RpY2UoeyBvd25lcjogZGF0YS5pZCwgdGV4dDogYFByZcOnbyBvdSBkaXNwb25pYmlsaWRhZGUgYXR1YWxpemFkbzogJHtjaGFuZ2VkLm1hcCgobGluZSkgPT4gbGluZS5uZnQubmFtZSkuam9pbignLCAnKX0uIFJldmlzZSBvIGNhcnJpbmhvIGFudGVzIGRlIGNvbnRpbnVhci5gIH0pXG4gIH0sIFtkYXRhXSlcblxuICBhc3luYyBmdW5jdGlvbiBtdXRhdGUoYWN0aW9uOiAnY2hhbmdlJyB8ICdyZW1vdmUnIHwgJ2FwcGx5JyB8ICdyZW1vdmVDb3Vwb24nLCBsaW5lSWQgPSAnJywgcXVhbnRpdHkgPSAwKSB7XG4gICAgaWYgKGJ1c3kpIHJldHVyblxuICAgIHNldEJ1c3kodHJ1ZSk7IHNldE1lc3NhZ2UoJycpOyBzZXRDb3Vwb25FcnJvcihmYWxzZSlcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBjYXJ0OiBjbGllbnQgfSA9IGF3YWl0IGltcG9ydCgnLi4vLi4vYXBwL21hcmtldHBsYWNlLXNlcnZpY2VzLnRzJylcbiAgICAgIGNvbnN0IGN1cnJlbnQgPSBhd2FpdCBjbGllbnQucmVjb25jaWxlKClcbiAgICAgIGlmIChhY3Rpb24gPT09ICdjaGFuZ2UnKSBhd2FpdCBjbGllbnQuY2hhbmdlKGxpbmVJZCwgcXVhbnRpdHksIGN1cnJlbnQucmV2aXNpb24pXG4gICAgICBlbHNlIGlmIChhY3Rpb24gPT09ICdyZW1vdmUnKSBhd2FpdCBjbGllbnQucmVtb3ZlKGxpbmVJZCwgY3VycmVudC5yZXZpc2lvbilcbiAgICAgIGVsc2UgaWYgKGFjdGlvbiA9PT0gJ2FwcGx5JykgYXdhaXQgY2xpZW50LmFwcGx5Q291cG9uKGNvdXBvbiwgY3VycmVudC5yZXZpc2lvbilcbiAgICAgIGVsc2UgYXdhaXQgY2xpZW50LnJlbW92ZUNvdXBvbihjdXJyZW50LnJldmlzaW9uKVxuICAgICAgaWYgKGFjdGlvbiA9PT0gJ2FwcGx5JyB8fCBhY3Rpb24gPT09ICdyZW1vdmVDb3Vwb24nKSBzZXRDb3Vwb24oJycpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnN0IHRleHQgPSBheGlvcy5pc0F4aW9zRXJyb3IoZXJyb3IpID8gZXJyb3IucmVzcG9uc2U/LmRhdGE/LmVycm9yPy5tZXNzYWdlIDogdW5kZWZpbmVkXG4gICAgICBzZXRDb3Vwb25FcnJvcihhY3Rpb24gPT09ICdhcHBseScpXG4gICAgICBzZXRNZXNzYWdlKHRleHQgfHwgJ07Do28gZm9pIHBvc3PDrXZlbCBhdHVhbGl6YXIgbyBjYXJyaW5oby4gVGVudGUgbm92YW1lbnRlLicpXG4gICAgfSBmaW5hbGx5IHsgc2V0QnVzeShmYWxzZSkgfVxuICB9XG4gIGFzeW5jIGZ1bmN0aW9uIHJldHJ5Q2FydCgpIHtcbiAgICBjb25zdCBnZW5lcmF0aW9uID0gc2Vzc2lvbk1hbmFnZXIuc2Vzc2lvbkdlbmVyYXRpb25cbiAgICBjb25zdCB7IHJlYWx0aW1lIH0gPSBhd2FpdCBpbXBvcnQoJy4uLy4uL2FwcC9yZWFsdGltZS50cycpXG4gICAgaWYgKHNlc3Npb25NYW5hZ2VyLnNlc3Npb25HZW5lcmF0aW9uICE9PSBnZW5lcmF0aW9uKSByZXR1cm5cbiAgICByZWFsdGltZS5yZXRyeVJlY29uY2lsaWF0aW9uKClcbiAgICBhd2FpdCBjYXJ0LnJlZmV0Y2goKVxuICB9XG4gIGZ1bmN0aW9uIGFwcGx5KGV2ZW50OiBGb3JtRXZlbnQ8SFRNTEZvcm1FbGVtZW50PikgeyBldmVudC5wcmV2ZW50RGVmYXVsdCgpOyBpZiAoY291cG9uLnRyaW0oKSkgdm9pZCBtdXRhdGUoJ2FwcGx5JykgfVxuICBmdW5jdGlvbiBjaGVja291dCgpIHtcbiAgICBpZiAoYmxvY2tlZCB8fCBidXN5KSByZXR1cm5cbiAgICB2b2lkIHJvdXRlci5uYXZpZ2F0ZSh7IGhyZWY6IHNlc3Npb25NYW5hZ2VyLnNlc3Npb24gPyAnL2NoZWNrb3V0JyA6ICcvbG9naW4/cmV0dXJuVG89JTJGY2hlY2tvdXQnIH0pXG4gIH1cbiAgcmV0dXJuIDxtYWluIGNsYXNzTmFtZT1cImNhcnQtcGFnZVwiPlxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FydC1kZXNrdG9wLWhlYWRlclwiPjxBY2NvdW50SGVhZGVyIGFjdGl2ZT1cIm1hcmtldFwiIC8+PC9kaXY+XG4gICAgPGRpdiBjbGFzc05hbWU9XCJjYXJ0LWxheW91dFwiPjxzZWN0aW9uIGNsYXNzTmFtZT1cImNhcnQtY29udGVudFwiPjxkaXYgY2xhc3NOYW1lPVwiY2FydC10aXRsZVwiPjxhIGhyZWY9XCIvXCIgYXJpYS1sYWJlbD1cIlZvbHRhciBhbyBpbsOtY2lvXCI+PGltZyBzcmM9XCIvYXNzZXRzL2ljb25zL2JhY2stZGV0YWlsLW1vYmlsZS5zdmdcIiBhbHQ9XCJcIiAvPjwvYT48aDE+Q2FycmluaG8gZGUgTkZUczwvaDE+PC9kaXY+PHAgY2xhc3NOYW1lPVwiY2FydC1icmVhZGNydW1iXCI+SW7DrWNpbyAvIE1lcmNhZG8gLyBDYXJyaW5obzwvcD5cbiAgICAgIHshZGF0YSAmJiAoIXJlYWR5IHx8IGNhcnQuaXNQZW5kaW5nKSA/IDxMb2FkaW5nU2tlbGV0b24ga2luZD1cImNhcnRcIiAvPiA6ICFkYXRhID8gPGRpdiByb2xlPVwiYWxlcnRcIj5Ow6NvIGZvaSBwb3Nzw612ZWwgY2FycmVnYXIgbyBjYXJyaW5oby4gPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gdm9pZCBjYXJ0LnJlZmV0Y2goKX0+VGVudGFyIG5vdmFtZW50ZTwvYnV0dG9uPjwvZGl2PiA6IGRhdGEubGluZXMubGVuZ3RoID09PSAwID8gPHAgY2xhc3NOYW1lPVwiY2FydC1lbXB0eVwiPlNldSBjYXJyaW5obyBlc3TDoSB2YXppby4gPGEgaHJlZj1cIi9cIj5Db250aW51YXIgZXhwbG9yYW5kbzwvYT48L3A+IDogPD48ZGl2IGNsYXNzTmFtZT1cImNhcnQtdGFibGUtaGVhZFwiPjxzcGFuPk5GVHM8L3NwYW4+PHNwYW4+UHJlw6dvPC9zcGFuPjxzcGFuPkVkacOnw7Vlczwvc3Bhbj48c3Bhbj5Ub3RhbDwvc3Bhbj48L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImNhcnQtbGluZXNcIj57ZGF0YS5saW5lcy5tYXAoKGxpbmUpID0+IDxhcnRpY2xlIGNsYXNzTmFtZT1cImNhcnQtbGluZVwiIGtleT17bGluZS5saW5lSWR9PjxpbWcgc3JjPXtsaW5lLm5mdC5hcnRVcmx9IGFsdD1cIlwiIC8+PGltZyBjbGFzc05hbWU9XCJjYXJ0LWFydC1vdmVybGF5XCIgc3JjPXtsaW5lLm5mdC5hcnRVcmx9IGFsdD1cIlwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+PGRpdiBjbGFzc05hbWU9XCJjYXJ0LWxpbmUtaW5mb1wiPjxzdHJvbmc+e2xpbmUubmZ0Lm5hbWV9PC9zdHJvbmc+PHNwYW4gY2xhc3NOYW1lPVwiY2FydC1lZGl0aW9uXCI+RWRpw6fDo286IHtsaW5lLm5mdC5lZGl0aW9ucy5maW5kKChlZGl0aW9uKSA9PiBlZGl0aW9uLmlkID09PSBsaW5lLmVkaXRpb25JZCk/LmxhYmVsfTwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJjYXJ0LXRva2VuXCI+SUQgZG8gdG9rZW46IHtsaW5lLm5mdC50b2tlbklkfTwvc3Bhbj48Yj57Zm9ybWF0RXRoKGxpbmVUb3RhbChsaW5lLnVuaXRQcmljZSwgbGluZS5xdWFudGl0eSkpfSBFVEg8L2I+e2xpbmUucXVhbnRpdHkgPiBsaW5lLmF2YWlsYWJsZSAmJiA8c3BhbiByb2xlPVwiYWxlcnRcIj5Fc3RvcXVlIGRpc3BvbsOtdmVsOiB7bGluZS5hdmFpbGFibGV9PC9zcGFuPn08L2Rpdj48c3BhbiBjbGFzc05hbWU9XCJjYXJ0LXVuaXRcIj57bGluZS51bml0UHJpY2V9IEVUSDwvc3Bhbj48ZGl2IGNsYXNzTmFtZT1cImNhcnQtc3RlcHBlclwiPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGFyaWEtbGFiZWw9e2BEaW1pbnVpciBxdWFudGlkYWRlIGRlICR7bGluZS5uZnQubmFtZX1gfSBkaXNhYmxlZD17YnVzeSB8fCAhcmVhZHkgfHwgbGluZS5xdWFudGl0eSA8PSAxfSBvbkNsaWNrPXsoKSA9PiB2b2lkIG11dGF0ZSgnY2hhbmdlJywgbGluZS5saW5lSWQsIGxpbmUucXVhbnRpdHkgLSAxKX0+4oiSPC9idXR0b24+PHNwYW4+e2xpbmUucXVhbnRpdHl9PC9zcGFuPjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGFyaWEtbGFiZWw9e2BBdW1lbnRhciBxdWFudGlkYWRlIGRlICR7bGluZS5uZnQubmFtZX1gfSBkaXNhYmxlZD17YnVzeSB8fCAhcmVhZHkgfHwgbGluZS5xdWFudGl0eSA+PSBsaW5lLmF2YWlsYWJsZX0gb25DbGljaz17KCkgPT4gdm9pZCBtdXRhdGUoJ2NoYW5nZScsIGxpbmUubGluZUlkLCBsaW5lLnF1YW50aXR5ICsgMSl9Pis8L2J1dHRvbj48L2Rpdj48c3BhbiBjbGFzc05hbWU9XCJjYXJ0LWxpbmUtdG90YWxcIj57Zm9ybWF0RXRoKGxpbmVUb3RhbChsaW5lLnVuaXRQcmljZSwgbGluZS5xdWFudGl0eSkpfSBFVEg8L3NwYW4+PGJ1dHRvbiBjbGFzc05hbWU9XCJjYXJ0LXJlbW92ZVwiIHR5cGU9XCJidXR0b25cIiBkaXNhYmxlZD17YnVzeSB8fCAhcmVhZHl9IG9uQ2xpY2s9eygpID0+IHZvaWQgbXV0YXRlKCdyZW1vdmUnLCBsaW5lLmxpbmVJZCl9IGFyaWEtbGFiZWw9e2BSZW1vdmVyICR7bGluZS5uZnQubmFtZX1gfT48cGljdHVyZT48c291cmNlIG1lZGlhPVwiKG1pbi13aWR0aDogMTI4MHB4KVwiIHNyY1NldD1cIi9hc3NldHMvaWNvbnMvY2FydC1yZW1vdmUtZGVza3RvcC5zdmdcIiAvPjxpbWcgc3JjPVwiL2Fzc2V0cy9pY29ucy9jYXJ0LXJlbW92ZS5zdmdcIiBhbHQ9XCJcIiAvPjwvcGljdHVyZT48L2J1dHRvbj48L2FydGljbGU+KX08L2Rpdj48Lz59XG4gICAgPC9zZWN0aW9uPjxzZWN0aW9uIGNsYXNzTmFtZT1cImNhcnQtc3VtbWFyeVwiIGFyaWEtbGFiZWw9XCJSZXN1bW8gZGEgY2FydGVpcmFcIj48aDI+UmVzdW1vIGRhIGNhcnRlaXJhPC9oMj57ZGF0YSAmJiBjYXJ0LmlzRXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiY2FydC1lcnJvclwiIHJvbGU9XCJhbGVydFwiPk7Do28gZm9pIHBvc3PDrXZlbCBhdHVhbGl6YXIgbyBjYXJyaW5oby4gT3MgdmFsb3JlcyBleGliaWRvcyBwb2RlbSBlc3RhciBkZXNhdHVhbGl6YWRvcy4gPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gdm9pZCByZXRyeUNhcnQoKX0+VGVudGFyIG5vdmFtZW50ZTwvYnV0dG9uPjwvcD59e2RhdGEgJiYgY2FydC5pc0ZldGNoaW5nICYmIDxwIHJvbGU9XCJzdGF0dXNcIj5BdHVhbGl6YW5kbyBvIGNhcnJpbmhvLi4uPC9wPn17Y2hhbmdlTm90aWNlICYmIGRhdGE/LmlkID09PSBjaGFuZ2VOb3RpY2Uub3duZXIgJiYgPHAgY2xhc3NOYW1lPVwiY2FydC1lcnJvclwiIHJvbGU9XCJzdGF0dXNcIj57Y2hhbmdlTm90aWNlLnRleHR9PC9wPn08Zm9ybSBvblN1Ym1pdD17YXBwbHl9PjxsYWJlbCBodG1sRm9yPVwiY291cG9uXCIgY2xhc3NOYW1lPVwiY2FydC1jb3Vwb24tbGFiZWxcIj5Dw7NkaWdvIHByb21vY2lvbmFsPC9sYWJlbD48ZGl2IGNsYXNzTmFtZT1cImNhcnQtY291cG9uXCI+PGlucHV0IGlkPVwiY291cG9uXCIgdmFsdWU9e2NvdXBvbn0gb25DaGFuZ2U9eyhldmVudCkgPT4geyBzZXRDb3Vwb24oZXZlbnQudGFyZ2V0LnZhbHVlKTsgaWYgKGNvdXBvbkVycm9yKSB7IHNldENvdXBvbkVycm9yKGZhbHNlKTsgc2V0TWVzc2FnZSgnJykgfSB9fSBhcmlhLWludmFsaWQ9e2NvdXBvbkVycm9yfSBhcmlhLWRlc2NyaWJlZGJ5PXtjb3Vwb25FcnJvciA/ICdjYXJ0LWVycm9yJyA6IHVuZGVmaW5lZH0gcGxhY2Vob2xkZXI9XCJEaWdpdGUgbyBjw7NkaWdvIHByb21vY2lvbmFsLi4uXCIgLz48YnV0dG9uIGRpc2FibGVkPXtidXN5IHx8ICFyZWFkeSB8fCAhY291cG9uLnRyaW0oKX0+QXBsaWNhcjwvYnV0dG9uPjwvZGl2PjwvZm9ybT57ZGF0YT8uY291cG9uQ29kZSAmJiA8cCBjbGFzc05hbWU9XCJjYXJ0LWFwcGxpZWRcIj57ZGF0YS5jb3Vwb25Db2RlfSA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBkaXNhYmxlZD17YnVzeSB8fCAhcmVhZHl9IG9uQ2xpY2s9eygpID0+IHZvaWQgbXV0YXRlKCdyZW1vdmVDb3Vwb24nKX0+UmVtb3ZlciBjdXBvbTwvYnV0dG9uPjwvcD59e21lc3NhZ2UgJiYgPHAgaWQ9XCJjYXJ0LWVycm9yXCIgY2xhc3NOYW1lPVwiY2FydC1lcnJvclwiIHJvbGU9XCJhbGVydFwiPnttZXNzYWdlfTwvcD59e2RhdGE/LmFkanVzdG1lbnRzLm1hcCgoYWRqdXN0bWVudCkgPT4gPHAgY2xhc3NOYW1lPVwiY2FydC1lcnJvclwiIHJvbGU9XCJzdGF0dXNcIiBrZXk9e2FkanVzdG1lbnR9PnthZGp1c3RtZW50ID09PSAnQ09VUE9OX0VYUElSRUQnID8gJ08gY3Vwb20gZXhwaXJvdS4nIDogYWRqdXN0bWVudH08L3A+KX1cbiAgICAgIHtkYXRhPy5xdW90ZSA/IDxkbCBjbGFzc05hbWU9XCJjYXJ0LXRvdGFsc1wiPjxkaXY+PGR0PlN1YnRvdGFsPC9kdD48ZGQ+e2RhdGEucXVvdGUuc3VidG90YWx9IEVUSDwvZGQ+PC9kaXY+PGRpdj48ZHQ+RGVzY29udG8gZG8gbGFuw6dhbWVudG88L2R0PjxkZD4o4oiSKSB7ZGF0YS5xdW90ZS5kaXNjb3VudH08L2RkPjwvZGl2PjxkaXY+PGR0PlRheGEgZGUgcmVkZTwvZHQ+PGRkPntkYXRhLnF1b3RlLm5ldHdvcmtGZWV9IEVUSDxzbWFsbD5UYXhhIGVzdGltYWRhPC9zbWFsbD48L2RkPjwvZGl2PjxkaXYgY2xhc3NOYW1lPVwiY2FydC10b3RhbFwiPjxkdD5Ub3RhbDwvZHQ+PGRkPntkYXRhLnF1b3RlLnRvdGFsfSBFVEg8L2RkPjwvZGl2PjwvZGw+IDogZGF0YSB8fCBjYXJ0LmlzRXJyb3IgPyA8cCByb2xlPVwiYWxlcnRcIj5SZXN1bW8gaW5kaXNwb27DrXZlbC4gPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gdm9pZCByZXRyeUNhcnQoKX0+VGVudGFyIG5vdmFtZW50ZTwvYnV0dG9uPjwvcD4gOiA8TG9hZGluZ1NrZWxldG9uIGtpbmQ9XCJzdW1tYXJ5XCIgLz59XG4gICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImNhcnQtY2hlY2tvdXRcIiB0eXBlPVwiYnV0dG9uXCIgZGlzYWJsZWQ9e2Jsb2NrZWQgfHwgYnVzeSB8fCAhcmVhZHl9IG9uQ2xpY2s9e2NoZWNrb3V0fT5Db25lY3RhciBlIGZpbmFsaXphcjwvYnV0dG9uPjxhIGNsYXNzTmFtZT1cImNhcnQtY29udGludWVcIiBocmVmPVwiL1wiPkNvbnRpbnVhciBleHBsb3JhbmRvPC9hPlxuICAgIDwvc2VjdGlvbj48L2Rpdj48c2VjdGlvbiBjbGFzc05hbWU9XCJjYXJ0LXJlY29tbWVuZGF0aW9uc1wiIGFyaWEtbGFiZWxsZWRieT1cImNhcnQtcmVjb21tZW5kYXRpb25zLXRpdGxlXCI+PGgyIGlkPVwiY2FydC1yZWNvbW1lbmRhdGlvbnMtdGl0bGVcIj5Db2xlY2lvbmFkb3JlcyB0YW1iw6ltIHZpcmFtPC9oMj57cmVjb21tZW5kYXRpb25zLmlzUGVuZGluZyA/IDxwIHJvbGU9XCJzdGF0dXNcIj5DYXJyZWdhbmRvIE5GVHMuLi48L3A+IDogcmVjb21tZW5kYXRpb25zLmlzRXJyb3IgPyA8cCByb2xlPVwiYWxlcnRcIj5Ow6NvIGZvaSBwb3Nzw612ZWwgY2FycmVnYXIgb3MgTkZUcy4gPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gdm9pZCByZWNvbW1lbmRhdGlvbnMucmVmZXRjaCgpfT5UZW50YXIgbm92YW1lbnRlPC9idXR0b24+PC9wPiA6IDxkaXYgY2xhc3NOYW1lPVwiY2FydC1yZWNvbW1lbmRhdGlvbi1ncmlkXCI+e3JlY29tbWVuZGF0aW9ucy5kYXRhPy5pdGVtcy5zbGljZSgzLCA4KS5tYXAoKG5mdCkgPT4gPGFydGljbGUga2V5PXtuZnQuaWR9PjxhIGhyZWY9e2AvbmZ0cy8ke2VuY29kZVVSSUNvbXBvbmVudChuZnQuaWQpfWB9PjxzcGFuIGNsYXNzTmFtZT1cImNhcnQtcmVjb21tZW5kYXRpb24tYXJ0XCI+PGltZyBzcmM9e25mdC5hcnRVcmx9IGFsdD1cIlwiIC8+PC9zcGFuPjxzcGFuPntuZnQubmFtZX08L3NwYW4+PHN0cm9uZz57bmZ0LmVkaXRpb25zWzBdPy51bml0UHJpY2V9IEVUSDwvc3Ryb25nPjwvYT48L2FydGljbGU+KX08L2Rpdj59PGRpdiBjbGFzc05hbWU9XCJjYXJ0LXJlY29tbWVuZGF0aW9uLWRvdHNcIiBhcmlhLWhpZGRlbj1cInRydWVcIj48aSAvPjxpIC8+PGkgLz48L2Rpdj48L3NlY3Rpb24+PGRpdiBjbGFzc05hbWU9XCJjYXJ0LWZvb3RlclwiPjxGb290ZXIgLz48L2Rpdj5cbiAgPC9tYWluPlxufVxuIl19