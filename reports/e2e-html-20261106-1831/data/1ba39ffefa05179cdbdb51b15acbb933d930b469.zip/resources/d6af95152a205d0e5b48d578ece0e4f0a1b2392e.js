/** Query keys begin with resource name; private keys also include owner and generation. */
function matches(query, resources, ownerId) {
	const [resource, id, owner] = query.queryKey;
	if (query.meta?.private === true && query.meta?.ownerId !== ownerId) return false;
	if (resource === "catalog") return resources.catalog;
	if (resource === "nft") return typeof id === "string" && resources.nftIds.includes(id);
	if (resource === "cart" || resource === "quote") return ownerId !== null ? query.meta?.private === true && query.meta?.ownerId === ownerId : query.meta?.visitor === true && query.meta?.private !== true;
	if (resource === "profile" || resource === "wallets" || resource === "favorites") return ownerId !== null && query.meta?.private === true && query.meta?.ownerId === ownerId;
	if (resource === "order") return typeof id === "string" && resources.orderIds.includes(id) && owner === ownerId;
	return false;
}
export function createQueryReconciliation(queries, ownerId) {
	return {
		async reconcile(resources) {
			await queries.invalidateQueries({
				predicate: (query) => matches(query, resources, ownerId),
				refetchType: "active"
			}, { throwOnError: true });
		},
		async refresh(event) {
			await queries.invalidateQueries({
				predicate: (query) => {
					if (query.meta?.private === true && query.meta?.ownerId !== ownerId) return false;
					const [resource, id, owner] = query.queryKey;
					if (event.type === "nft.updated") {
						const cartOwned = (resource === "cart" || resource === "quote") && (ownerId === null ? query.meta?.visitor === true && query.meta?.private !== true : query.meta?.private === true && query.meta?.ownerId === ownerId);
						const favoritesOwned = resource === "favorites" && ownerId !== null && query.meta?.private === true && query.meta?.ownerId === ownerId;
						return resource === "catalog" || cartOwned || favoritesOwned || resource === "nft" && id === event.resourceId;
					}
					return resource === "order" && id === event.resourceId && owner === ownerId;
				},
				refetchType: "active"
			}, { throwOnError: true });
		}
	};
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IjtBQUtBLFNBQVMsUUFBUSxPQUFjLFdBQThCLFNBQXdCO0NBQ25GLE1BQU0sQ0FBQyxVQUFVLElBQUksU0FBUyxNQUFNO0NBQ3BDLElBQUksTUFBTSxNQUFNLFlBQVksUUFBUSxNQUFNLE1BQU0sWUFBWSxTQUFTLE9BQU87Q0FDNUUsSUFBSSxhQUFhLFdBQVcsT0FBTyxVQUFVO0NBQzdDLElBQUksYUFBYSxPQUFPLE9BQU8sT0FBTyxPQUFPLFlBQVksVUFBVSxPQUFPLFNBQVMsRUFBRTtDQUNyRixJQUFJLGFBQWEsVUFBVSxhQUFhLFNBQVMsT0FBTyxZQUFZLE9BQU8sTUFBTSxNQUFNLFlBQVksUUFBUSxNQUFNLE1BQU0sWUFBWSxVQUFVLE1BQU0sTUFBTSxZQUFZLFFBQVEsTUFBTSxNQUFNLFlBQVk7Q0FDck0sSUFBSSxhQUFhLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxPQUFPLFlBQVksUUFBUSxNQUFNLE1BQU0sWUFBWSxRQUFRLE1BQU0sTUFBTSxZQUFZO0NBQ3JLLElBQUksYUFBYSxTQUFTLE9BQU8sT0FBTyxPQUFPLFlBQVksVUFBVSxTQUFTLFNBQVMsRUFBRSxLQUFLLFVBQVU7Q0FDeEcsT0FBTztBQUNUO0FBRUEsT0FBTyxTQUFTLDBCQUEwQixTQUFzQixTQUF3QjtDQUN0RixPQUFPO0VBQ0wsTUFBTSxVQUFVLFdBQThCO0dBQzVDLE1BQU0sUUFBUSxrQkFBa0I7SUFBRSxZQUFZLFVBQVUsUUFBUSxPQUFPLFdBQVcsT0FBTztJQUFHLGFBQWE7R0FBUyxHQUFHLEVBQUUsY0FBYyxLQUFLLENBQUM7RUFDN0k7RUFDQSxNQUFNLFFBQVEsT0FBc0I7R0FDbEMsTUFBTSxRQUFRLGtCQUFrQjtJQUM5QixZQUFZLFVBQVU7S0FDcEIsSUFBSSxNQUFNLE1BQU0sWUFBWSxRQUFRLE1BQU0sTUFBTSxZQUFZLFNBQVMsT0FBTztLQUM1RSxNQUFNLENBQUMsVUFBVSxJQUFJLFNBQVMsTUFBTTtLQUNwQyxJQUFJLE1BQU0sU0FBUyxlQUFlO01BQ2hDLE1BQU0sYUFBYSxhQUFhLFVBQVUsYUFBYSxhQUFhLFlBQVksT0FBTyxNQUFNLE1BQU0sWUFBWSxRQUFRLE1BQU0sTUFBTSxZQUFZLE9BQU8sTUFBTSxNQUFNLFlBQVksUUFBUSxNQUFNLE1BQU0sWUFBWTtNQUM5TSxNQUFNLGlCQUFpQixhQUFhLGVBQWUsWUFBWSxRQUFRLE1BQU0sTUFBTSxZQUFZLFFBQVEsTUFBTSxNQUFNLFlBQVk7TUFDL0gsT0FBTyxhQUFhLGFBQWEsYUFBYSxrQkFBbUIsYUFBYSxTQUFTLE9BQU8sTUFBTTtLQUN0RztLQUNBLE9BQU8sYUFBYSxXQUFXLE9BQU8sTUFBTSxjQUFjLFVBQVU7SUFDdEU7SUFDQSxhQUFhO0dBQ2YsR0FBRyxFQUFFLGNBQWMsS0FBSyxDQUFDO0VBQzNCO0NBQ0Y7QUFDRiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJxdWVyeS1yZWNvbmNpbGlhdGlvbi50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFF1ZXJ5LCBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB0eXBlIHsgUmVhbHRpbWVFdmVudCB9IGZyb20gJy4vZXZlbnQtZ2F0ZS50cydcbmltcG9ydCB0eXBlIHsgUmVhbHRpbWVSZXNvdXJjZXMgfSBmcm9tICcuL3N5bmNocm9uaXplci50cydcblxuLyoqIFF1ZXJ5IGtleXMgYmVnaW4gd2l0aCByZXNvdXJjZSBuYW1lOyBwcml2YXRlIGtleXMgYWxzbyBpbmNsdWRlIG93bmVyIGFuZCBnZW5lcmF0aW9uLiAqL1xuZnVuY3Rpb24gbWF0Y2hlcyhxdWVyeTogUXVlcnksIHJlc291cmNlczogUmVhbHRpbWVSZXNvdXJjZXMsIG93bmVySWQ6IHN0cmluZyB8IG51bGwpIHtcbiAgY29uc3QgW3Jlc291cmNlLCBpZCwgb3duZXJdID0gcXVlcnkucXVlcnlLZXlcbiAgaWYgKHF1ZXJ5Lm1ldGE/LnByaXZhdGUgPT09IHRydWUgJiYgcXVlcnkubWV0YT8ub3duZXJJZCAhPT0gb3duZXJJZCkgcmV0dXJuIGZhbHNlXG4gIGlmIChyZXNvdXJjZSA9PT0gJ2NhdGFsb2cnKSByZXR1cm4gcmVzb3VyY2VzLmNhdGFsb2dcbiAgaWYgKHJlc291cmNlID09PSAnbmZ0JykgcmV0dXJuIHR5cGVvZiBpZCA9PT0gJ3N0cmluZycgJiYgcmVzb3VyY2VzLm5mdElkcy5pbmNsdWRlcyhpZClcbiAgaWYgKHJlc291cmNlID09PSAnY2FydCcgfHwgcmVzb3VyY2UgPT09ICdxdW90ZScpIHJldHVybiBvd25lcklkICE9PSBudWxsID8gcXVlcnkubWV0YT8ucHJpdmF0ZSA9PT0gdHJ1ZSAmJiBxdWVyeS5tZXRhPy5vd25lcklkID09PSBvd25lcklkIDogcXVlcnkubWV0YT8udmlzaXRvciA9PT0gdHJ1ZSAmJiBxdWVyeS5tZXRhPy5wcml2YXRlICE9PSB0cnVlXG4gIGlmIChyZXNvdXJjZSA9PT0gJ3Byb2ZpbGUnIHx8IHJlc291cmNlID09PSAnd2FsbGV0cycgfHwgcmVzb3VyY2UgPT09ICdmYXZvcml0ZXMnKSByZXR1cm4gb3duZXJJZCAhPT0gbnVsbCAmJiBxdWVyeS5tZXRhPy5wcml2YXRlID09PSB0cnVlICYmIHF1ZXJ5Lm1ldGE/Lm93bmVySWQgPT09IG93bmVySWRcbiAgaWYgKHJlc291cmNlID09PSAnb3JkZXInKSByZXR1cm4gdHlwZW9mIGlkID09PSAnc3RyaW5nJyAmJiByZXNvdXJjZXMub3JkZXJJZHMuaW5jbHVkZXMoaWQpICYmIG93bmVyID09PSBvd25lcklkXG4gIHJldHVybiBmYWxzZVxufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlUXVlcnlSZWNvbmNpbGlhdGlvbihxdWVyaWVzOiBRdWVyeUNsaWVudCwgb3duZXJJZDogc3RyaW5nIHwgbnVsbCkge1xuICByZXR1cm4ge1xuICAgIGFzeW5jIHJlY29uY2lsZShyZXNvdXJjZXM6IFJlYWx0aW1lUmVzb3VyY2VzKSB7XG4gICAgICBhd2FpdCBxdWVyaWVzLmludmFsaWRhdGVRdWVyaWVzKHsgcHJlZGljYXRlOiAocXVlcnkpID0+IG1hdGNoZXMocXVlcnksIHJlc291cmNlcywgb3duZXJJZCksIHJlZmV0Y2hUeXBlOiAnYWN0aXZlJyB9LCB7IHRocm93T25FcnJvcjogdHJ1ZSB9KVxuICAgIH0sXG4gICAgYXN5bmMgcmVmcmVzaChldmVudDogUmVhbHRpbWVFdmVudCkge1xuICAgICAgYXdhaXQgcXVlcmllcy5pbnZhbGlkYXRlUXVlcmllcyh7XG4gICAgICAgIHByZWRpY2F0ZTogKHF1ZXJ5KSA9PiB7XG4gICAgICAgICAgaWYgKHF1ZXJ5Lm1ldGE/LnByaXZhdGUgPT09IHRydWUgJiYgcXVlcnkubWV0YT8ub3duZXJJZCAhPT0gb3duZXJJZCkgcmV0dXJuIGZhbHNlXG4gICAgICAgICAgY29uc3QgW3Jlc291cmNlLCBpZCwgb3duZXJdID0gcXVlcnkucXVlcnlLZXlcbiAgICAgICAgICBpZiAoZXZlbnQudHlwZSA9PT0gJ25mdC51cGRhdGVkJykge1xuICAgICAgICAgICAgY29uc3QgY2FydE93bmVkID0gKHJlc291cmNlID09PSAnY2FydCcgfHwgcmVzb3VyY2UgPT09ICdxdW90ZScpICYmIChvd25lcklkID09PSBudWxsID8gcXVlcnkubWV0YT8udmlzaXRvciA9PT0gdHJ1ZSAmJiBxdWVyeS5tZXRhPy5wcml2YXRlICE9PSB0cnVlIDogcXVlcnkubWV0YT8ucHJpdmF0ZSA9PT0gdHJ1ZSAmJiBxdWVyeS5tZXRhPy5vd25lcklkID09PSBvd25lcklkKVxuICAgICAgICAgICAgY29uc3QgZmF2b3JpdGVzT3duZWQgPSByZXNvdXJjZSA9PT0gJ2Zhdm9yaXRlcycgJiYgb3duZXJJZCAhPT0gbnVsbCAmJiBxdWVyeS5tZXRhPy5wcml2YXRlID09PSB0cnVlICYmIHF1ZXJ5Lm1ldGE/Lm93bmVySWQgPT09IG93bmVySWRcbiAgICAgICAgICAgIHJldHVybiByZXNvdXJjZSA9PT0gJ2NhdGFsb2cnIHx8IGNhcnRPd25lZCB8fCBmYXZvcml0ZXNPd25lZCB8fCAocmVzb3VyY2UgPT09ICduZnQnICYmIGlkID09PSBldmVudC5yZXNvdXJjZUlkKVxuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gcmVzb3VyY2UgPT09ICdvcmRlcicgJiYgaWQgPT09IGV2ZW50LnJlc291cmNlSWQgJiYgb3duZXIgPT09IG93bmVySWRcbiAgICAgICAgfSxcbiAgICAgICAgcmVmZXRjaFR5cGU6ICdhY3RpdmUnLFxuICAgICAgfSwgeyB0aHJvd09uRXJyb3I6IHRydWUgfSlcbiAgICB9LFxuICB9XG59XG4iXX0=